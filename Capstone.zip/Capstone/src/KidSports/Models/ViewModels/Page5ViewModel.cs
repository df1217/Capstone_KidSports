﻿using KidSports.Models;
using Microsoft.AspNetCore.Http;

namespace KidSports.Models.ViewModels
{
    public class Page5ViewModel
    {
        public Application Application { get; set; }
        public IFormFile File { get; set; }
    }
}
