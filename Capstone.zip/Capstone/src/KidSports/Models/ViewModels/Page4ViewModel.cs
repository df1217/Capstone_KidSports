﻿using KidSports.Models;
using Microsoft.AspNetCore.Http;

namespace KidSports.Models.ViewModels
{
    public class Page4ViewModel
    {
        public Application Application { get; set; }
        public IFormFile File { get; set; }
    }
}
