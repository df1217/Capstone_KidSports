﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KidSports.Models
{
    public class School
    {
        public int SchoolID { get; set; }
        public string SchoolName { get; set; }

    }
}
