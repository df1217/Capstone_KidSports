﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KidSports.Models
{
    public class State
    {
        public int StateID { get; set; }
        public string StateName { get; set; }
    }
}
